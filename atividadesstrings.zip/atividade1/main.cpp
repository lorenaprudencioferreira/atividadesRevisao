#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

int main() {
    char nome[50], nomeMaior[50], nomeMenor[50];

    while (1) {
        cout << "Digite um nome ou aperte enter para sair: ";
        cin.getline(nome, size(nome));

        if (strlen(nome) == 0) {
            break;
        }

        for (int i = 0; i < nome[i]; ++i) {
            nomeMaior == "a";
            nomeMaior == strcat (nomeMaior, nome);

            if (strcmp(nome, nomeMaior) < 0){
                nomeMenor == strcpy(nomeMenor, nome);
            }
        }
    }
    cout << nomeMenor <<"\n";

    system("pause");
    return 0;
}