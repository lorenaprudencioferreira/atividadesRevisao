#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

int main() {
    char string[30], stringmod[30];
    int encontrado;

    cout << "\nInsira uma string: ";
    cin.getline(string, size(string));

    strcpy(stringmod, string);

    for (int i = 0; string[i]; i++) {
        stringmod[i];
        if (string[i] == 'a') {
            encontrado++;
            stringmod[i] = 'b';
        }
    }

    cout << "\nString digitada: " << string;
    cout << "\nModificados " << encontrado << " caracteres.";
    cout << "\nString modificada: " << stringmod;
    cout << "\n";

    system("pause");
    return 0;
}