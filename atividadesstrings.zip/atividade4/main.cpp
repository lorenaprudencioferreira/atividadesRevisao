#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

int main() {
    char cargo[30];
    float salarioAntigo, novoSalario = 0, dif = 0, porcentagem = 0;

    cout << "Seu cargo: ";
    cin.getline(cargo, size(cargo));

    cout << "Seu salario: ";
    cin >> salarioAntigo;

    if(stricmp(cargo, "Gerente") == 0){
        porcentagem = 10;
        dif = porcentagem / 100 * salarioAntigo;
        novoSalario = dif + salarioAntigo;
    }

    else if(stricmp(cargo, "Engenheiro") == 0){
        porcentagem = 20;
        dif = porcentagem / 100 * salarioAntigo;
        novoSalario = dif + salarioAntigo;
    }

    else if(stricmp(cargo, "Tecnico") == 0){
        porcentagem = 30;
        dif = porcentagem / 100 * salarioAntigo;
        novoSalario = dif + salarioAntigo;
    } else {
        porcentagem = 5;
        dif = porcentagem / 100 * salarioAntigo;
        novoSalario = dif + salarioAntigo;
    }

    cout << "\nSalario antigo: " << salarioAntigo;
    cout << "\nSalario novo: " << novoSalario;
    cout << "\nDiferenca: " << dif;
    cout << "\n";

    system("pause");
    return 0;
}