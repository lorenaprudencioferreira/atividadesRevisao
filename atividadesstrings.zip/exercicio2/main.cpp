#include <iostream>
#include <cstring>
using namespace std;

int main() {
    char string1[30];
    char string2[30];
    int tamanhototal;

    cout << "Insira uma string: ";
    cin.getline(string1, size(string1));

    cout << "Insira a segunda string: ";
    cin.getline(string2, size(string2));

    cout << "Primeira string: " << string1 << "\n" << "Segunda string: " << string2 << "\n";

    tamanhototal = strlen(string2);

    cout << "A segunda letra da primeira string e: " << string1[1] << "\n";
    cout << "A penultima letra da segunda string e: " << string2[tamanhototal - 2] << "\n";

    return 0;
}
